mapboxgl.accessToken = mapToken;

const map = new mapboxgl.Map({
    container: 'map',
    // Choose from Mapbox's core styles, or make your own style with Mapbox Studio
    style: 'mapbox://styles/mapbox/streets-v12',
    center: coordinates,
    zoom: 10
});


const marker = new mapboxgl.Marker({color:'red'})
.setLngLat(coordinates)
.setPopup(new mapboxgl.Popup({offset: 25})
.setHTML(`<h4>${mapLocation}</h4><p>Exact Location After Adding New Listing</p>`))
.addTo(map);