const User = require("../models/user.js");

module.exports.signupRender =  (req, res) => {
    res.render("users/signup.ejs");
  };

module.exports.signup = async (req, res) => {
    try {
      let { username, email, password } = req.body;
      const newUser = new User({ email, username });
      const registerUser = await User.register(newUser, password);
      console.log(registerUser);
      req.login(registerUser,(err)=>{
        if(err){
          return next(err);
        }
      req.flash("success", "Welcome To WanderLust");
      res.redirect("/listings");
      })
    } catch (e) {
      req.flash("error", e.message);
      res.redirect("/signup");
    }
  }

module.exports.loginRender = (req, res) => {
    res.render("users/login.ejs");
  };

module.exports.login = async(req, res) => {
    req.flash("success","Welcome Back To WanderLust ");
    let redirectUrl = res.locals.redirectUrl || "/listings"
    res.redirect(redirectUrl);
  };

module.exports.logout = (req,res,next)=>{
    req.logOut((err)=>{
      if(err){
       return next(err);
      }
      req.flash("success","Know You Logged Out From WanderLust!");
      res.redirect("/listings");
    })
  };