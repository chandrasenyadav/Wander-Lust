const express = require("express");
const router = express.Router();

//Index user

router.get("/",(req,res)=>{
    res.send("Get Posts")
})

//show users

router.get("/:id",(req,res)=>{
    res.send("Get posts ID")
})

//post -user
router.post("/",(req,res)=>{
    res.send("Post for posts ")
})

//delete -user
router.delete("/:id",(req,res)=>{
    res.send("Delete for posts id ")
})

module.exports = router;